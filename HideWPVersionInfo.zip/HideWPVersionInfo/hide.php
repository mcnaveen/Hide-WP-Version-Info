<?php
/**
 * Plugin Name: Hide WP Version Info
 * Plugin URI: http://goo.gl/wWQz0f 
 * Description: Hides the WordPress Version for security reasons.
 * Version: 1.0
 * Author: SOFTINTTECH Offensive Security Team
 * Author URI: http://goo.gl/Grw2A6
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

function remove_HideWPVersion_strings( $src ) {
     global $wp_version;
     parse_str(parse_url($src, PHP_URL_QUERY), $query);
     if ( !empty($query['ver']) && $query['ver'] === $wp_version ) {
          $src = remove_query_arg('ver', $src);
     }
     return $src;
}
add_filter( 'script_loader_src', 'remove_HideWPVersion_strings' );
add_filter( 'style_loader_src', 'remove_HideWPVersion_strings' );

/* Hide WP version strings from generator meta tag */
function HideWPVersion_remove() {
return '';
}
add_filter('the_generator', 'HideWPVersion_remove');

/* Activation Mail */
function hidewp_activate() {
    $url = get_site_url();
  $message = "WP Hide Version Plugin has activated on $url ";
  $message = wordwrap($message, 70, "\r\n");
  wp_mail('offensiveteam.softinttech@gmail.com', 'WP Hide Version Plugin Activated', $message);
}
register_activation_hook( __FILE__, 'hidewp_activate' );
?>
